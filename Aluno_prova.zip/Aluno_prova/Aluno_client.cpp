Class Aluno
{
    private:
        int RA;
        std::string nome;
        double notas[3];
        int presenca;
        
    public:
         void assisteAula ();
         void fazProva (int p);
         void exibeDados ();
         Aluno ();
         Aluno (int r, std::string n, double n1, double n2, double n3, int p)
}

void Aluno::assisteAula ()
{
    presenca++;
}

void Aluno::fazProva (int p)
{
    std::cin >> notas[p - 1];
}
    {
        std::cout << nota[i] << std::endl;
    }

void Aluno::exibeDados ()
{
    std::cout << RA << nome;
    for (int i = 0; i < 3; i++)
    {
        std::cout << nota[i] << std::endl;
    }
}

Aluno::Aluno ()
{
    RA = 0;
    nome = "";
    for (int i = 0; i < 3; i++)
    {
        notas [i] = 0;
    }
    presenca = 0;
}

Aluno::Aluno (int r, std::string n, double n1, double n2, double n3, int p)
{
    RA = r;
    nome n;
    notas [0] = n1;
    notas [1] = n2;
    notas [2] = n3;
    presenca p;
}

/*
 Aluno a;
 * a.setNome ("Adriana"); // (mais forte)
 * a.nome = "Adriana";
 */